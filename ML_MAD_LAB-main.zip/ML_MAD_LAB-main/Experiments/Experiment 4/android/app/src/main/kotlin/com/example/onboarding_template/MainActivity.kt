package com.example.onboarding_template

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
